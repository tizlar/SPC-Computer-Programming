﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App1
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        //method to perform square root
        static double sqrt(double num)
        {

            //assign input to x in babylonian formula and initialize y as 1
            double x = num;
            double y = 1;

            // e is the accuracy level in this method
            double e = 0.00000000001;

            while (x - y > e)
            {
                x = (x + y) / 2;
                y = num / x;
            }
            return x;
        }

        // actions that take place when button is clicked
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //create variable for user input
            double input;

            // try to parse the user entry as double
            try
            {
            input = double.Parse(userEntryTextBox.Text);
            
            // if user input is less than or equal to 0, return this message
            if (input <= 0)
            {
             resultsLabel.Text = "Results: Please enter a positive number";
            }
            // if user input is a vaild format, perform the square root function created above, and display results
            else
            {
            double calculatedValue = sqrt(input);
            resultsLabel.Text = "Results: The square root of " + input + " is " + calculatedValue;
            }
            
            }
            // if entry is not a double trigger this result
            catch
            {
            resultsLabel.Text = "Results: Please enter a double";
            }

        }
    }
}
