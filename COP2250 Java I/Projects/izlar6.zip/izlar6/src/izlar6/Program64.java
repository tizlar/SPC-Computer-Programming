// SPC ID 00002491103 Tristan Izlar


// to demonstrate overloading of functions, I made an overloaded method
// which will calculate the Hypotenuse of a triangle regardless of if the method arguments
// are integers or doubles. The overloaded method chooses the correct version of the method to run
// based off the inputs. The first result of the program is has been truncated to an integer, which
// indicates that it ran through the first version of the overloaded method at line 25, otherwise 
// the result would have been returned as a double. This version of the overloaded method was chosen due to 
// the int arguments provided at line 20.  We can see the opposite happened when 
// we had double arguments at line 21

package izlar6;

public class Program64 {
	public static void main(String[] args) {
		
		
		
		System.out.println("Side C is equal to length " + findHypotenuse(12, 13));
		System.out.println("Side C is equal to length " + findHypotenuse(5.64, 11.54));
		
	}
	
	public static int findHypotenuse(int sideA, int sideB) {
		int sideC = (int) Math.sqrt((Math.pow(sideA, 2) + Math.pow(sideB, 2)));
		return sideC;
	}
	
	public static double findHypotenuse(double sideA, double sideB) {
		double sideC = Math.sqrt((Math.pow(sideA, 2) + Math.pow(sideB, 2)));
		return sideC;
	}

}
