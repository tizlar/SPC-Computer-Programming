//Tristan Izlar SPC# 00002491103

// The following code prints out several lines using println
// println prints its argument on a new line

package izlar1and2;

public class Program1 {

	public static void main(String[] args) {
		System.out.println("The default data type for a number requiring decimals is double.");
		System.out.println("The default data type for whole numbers is int.");
		System.out.println("Constants should be named using all capitals and words should be seperated by underscores. Classes should always start with a capital letter for each word.");
		System.out.println("The class Scanner lets users input values into the console, and interact with the program being run.");
	}

}
