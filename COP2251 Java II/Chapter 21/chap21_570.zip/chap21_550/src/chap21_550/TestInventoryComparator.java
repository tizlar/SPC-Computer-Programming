// TreeInventoryComparator.java

package chap21_550;

import java.util.*;

public class TestInventoryComparator {

    public static void main(String[] args) {
    	
    	// NOTE: comparator created as arg to constructor 
        Set<InventoryValue> ts = new TreeSet<>(new InventoryComparator());
        ts.add(new InventoryValue("Shirts", 3, 12.50));
        ts.add(new InventoryValue("Shorts", 6, 20.00));
        ts.add(new InventoryValue("Shoes", 6, 50.00));        
        ts.add(new InventoryValue("Hats", 12, 14.99));
        
        System.out.println("Inventory Sorted by Total Value");         
        for( InventoryValue item: ts) {
            System.out.println(item);                    
        }
    }
}
