package chap21_550;

import java.util.*;

public class TestTreeSet {
  public static void main(String[] args) {
    // Create a hash set
    Set<String> set = new HashSet<String>();

    // Add strings to the set
    set.add("London");
    set.add("Paris");
    set.add("New York");
    set.add("San Francisco");
    set.add("Beijing");
    set.add("New York");

    // NOTE: argument set makes TreeSet from HashSet
    TreeSet<String> treeSet = new TreeSet<String>(set);
    System.out.println("Sorted tree set: " + treeSet);

    // Use the methods in SortedSet interface
    System.out.println("first(): " + treeSet.first());
    System.out.println("last(): " + treeSet.last());
    System.out.println("headSet(): " + treeSet.headSet("New York"));     // elements BEFORE New York
    System.out.println("tailSet(): " + treeSet.tailSet("New York"));     // New York and elements AFTER

    // Use the methods in NavigableSet interface
    System.out.println("lower(\"Paris\"): " + treeSet.lower("Paris"));   // just BEFORE Paris
    System.out.println("higher(\"Paris\"): " + treeSet.higher("Paris")); // just AFTER Paris
    System.out.println("floor(\"Paris\"): " + treeSet.floor("Paris"));   // largest < or == Paris
    System.out.println("ceiling(\"Paris\"): " + treeSet.ceiling("Paris")); // smallest > or == Paris
    System.out.println("pollFirst(): " + treeSet.pollFirst());           // returns and removes 1st element
    System.out.println("pollLast(): " + treeSet.pollLast());			 // returns and removes last element
    System.out.println("New tree set: " + treeSet);
  }
}
