// TreeInventoryComparator.java

package chap21_550;

import java.util.Arrays;
import java.util.Comparator;

public class TestInventoryComparator2 {

    public static void main(String[] args) {
    	
    	// NOTE: NO comparator created in constructor 
        InventoryValue[] inv = {new InventoryValue("Shirts", 3, 12.50),
        						new InventoryValue("Shorts", 6, 20.00),
        						new InventoryValue("Shoes", 6, 50.00),
        						new InventoryValue("Hats", 12, 14.99)
        					   };
     
        // sort using Comparator here
        Arrays.sort(inv, Comparator.comparing(e-> e.getValue()));
        
        System.out.println("Inventory Sorted by Total Value");         
        for( InventoryValue item: inv) {
            System.out.println(item);                    
        }
    }
}
