package chap21_550;

import java.util.*;

public class TestHashSet {
	public static void main(String[] args) {
		// Create a hash set
		Set<String> set = new HashSet<>();

		// Add strings to the set
		set.add("London");
		set.add("Paris");
		set.add("New York");
		set.add("San Francisco");
		set.add("Beijing");
		set.add("New York"); // not added, no duplicates allowed

		System.out.println(set); // a crude dump, NOTE not ordered

		// Display the elements in the hash set with foreach loop
		for (String s : set) {
			System.out.print(s.toUpperCase() + " ");
		}

		System.out.println(); // next with the forEach method and a lambda
		set.forEach(e -> System.out.print(e.toLowerCase() + " "));

		int tot = 0;	
		for (String s : set) { 
			tot += s.hashCode(); 
		} 
		
		System.out.println("\nHash code total " + tot);

		System.out.println("\nHashcodes of elements matches hashcode of collection? " + (tot == set.hashCode()));
	}
}