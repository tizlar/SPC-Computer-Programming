/* InventoryValue.java */

package chap21_550;

public class InventoryValue  {
	private String item;
    private int numInStock;
    private double unitPrice;
    
    public InventoryValue(String item, int numInStock, double unitPrice) {
		super();
		this.item = item;
		this.numInStock = numInStock;
		this.unitPrice = unitPrice;
	}

	public double getValue() {
        return numInStock * unitPrice;
    }

	@Override
	public String toString() {
		String s = item + ", " + numInStock + " in stock, price ";
		s += String.format("$%.2f",unitPrice) + ", value " + String.format("$%.2f", getValue());
		return s;
	}
	
	
}
