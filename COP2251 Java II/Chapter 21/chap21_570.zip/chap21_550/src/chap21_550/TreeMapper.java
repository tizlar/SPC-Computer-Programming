// TreeMapper.java

package chap21_550;

import java.util.*;
import java.util.Map.Entry;

public class TreeMapper {

    public static void main(String[] args) {
        TreeMap<String, String> cabinet = new TreeMap<String, String>();
        
        cabinet.put("Vice P", "Pence");
        cabinet.put("S State", "Pompeo");
        cabinet.put("S Treas", "Mnuchin");
        cabinet.put("S Def", "Esper");
        cabinet.put("S Int", "Bernhardt");
        cabinet.put("S HUD", "Carson");
        
        System.out.println(cabinet);  // crude dump
        // NOTE: the Map is sorted by key
        
        // one way to process the Map
        cabinet.forEach((k,v)-> System.out.println("Current " + k + " is " + v));
        System.out.println();
        
        // Another way...create a Set holding the Map keys
        Set<String> posts = cabinet.keySet();
        // loop through the set to get each key's value
        posts.forEach(e-> {
        	System.out.print("Current " + e + " is " + cabinet.get(e) + "\n");
        });
    }
}
