package chap20x;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class ChevDealer {

	public static void main(String[] args) {
		
		// cars with same model and same year but different prices
		Chevy v1 = new Chevy("Camaro",2017,22000);
		Chevy v2 = new Chevy("Cruze",2019,18000);
		Chevy v3 = new Chevy("Camaro",2017,20000);
		Chevy v4 = new Chevy("Corvette",2017,48000);
		Chevy v5 = new Chevy("Camaro",2017,24000);
		Chevy v6 = new Chevy("Cruze",2019,17000);
		Chevy v7 = new Chevy("Camaro",2019,29000);
		Chevy v8 = new Chevy("Corvette",2017,42000);
		
		// another nifty way to make an ArrayList from a small array
		ArrayList<Chevy> fleet = new ArrayList<>(Arrays.asList(v1,v2,v3,v4,v5,v6,v7,v8));		
		
		// now a 3-part sort
		Collections.sort(fleet,
				Comparator.comparing(Chevy::getModel).thenComparing(Chevy::getYear).thenComparing(Chevy::getPrice));
		
		// lambda with foreach method
		fleet.forEach(e -> System.out.println(e));
	}

}
