package chap20x;

public class FastFoodie {
	private String customer;
	private Integer orderNo;
	private String order;
	
	public FastFoodie(String customer, Integer orderNo, String order) {
		super();
		this.customer = customer;
		this.orderNo = orderNo;
		this.order = order;
	}

	public String getCustomer() {
		return customer;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public String getOrder() {
		return order;
	}

	@Override
	public String toString() {
		return "#" + orderNo + " Customer " + customer + ", order: " + order;
	}

}