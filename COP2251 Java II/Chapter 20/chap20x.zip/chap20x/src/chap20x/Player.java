package chap20x;

public class Player {
	
	private String name;
	private int weight;
	private int height;
	
	public Player(String name, int weight, int height) {
		super();
		this.name = name;
		this.weight = weight;
		this.height = height;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getHeight() {
		return height;
	}

	@Override
	public String toString() {
		return name + ", height " + height + ", weight " + weight;
	}
}
