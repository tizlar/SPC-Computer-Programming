package chap20x;

import java.util.Comparator;
import java.util.PriorityQueue;

public class Arches {

	public static void main(String[] args) {
		
        // Comparator to make orderNo the priority for customers in queue
		Comparator<FastFoodie> food = new Comparator<>() { 
            public int compare(FastFoodie ff1, FastFoodie ff2) { 
                return ff1.getOrderNo().compareTo(ff2.getOrderNo()); 
            } 
        };  
		// priority determined by orderNo as specified by food Comparator
		PriorityQueue<FastFoodie> line = new PriorityQueue<>(food);
	
		// offer method inserts elements into the queue 
		line.offer(new FastFoodie("Benny",345,"cheeseburger"));
		line.offer(new FastFoodie("Jenny",88,"hamburger"));
		line.offer(new FastFoodie("Kenny",101,"fries"));
		line.offer(new FastFoodie("Penny",222,"fish filet"));
		line.offer(new FastFoodie("Lenny",95,"mcRib"));
		line.offer(new FastFoodie("Denny",145,"salad"));
		
		// may I serve the next guest?
		System.out.println(line.poll());  // returns and removes Jenny
		
		System.out.println("Arches queue ordered by order number");
		while(line.size() > 0) {
			System.out.println(line.remove());
		}
		System.out.println("Queue empty? " + line.isEmpty());
	}
}
