package chap20x;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class CapCities {

	public static void main(String[] args) {
		
		City[] capitals = {
				new City("Pierre",14070,"South Dakota"),
				new City("Montpelier",7413,"Vermont"),
				new City("Juneau",32200,"Alaska"),
				new City("Phoenix",1600000,"Arizona"),
				new City("Albany",95000,"New York"),
				new City("Denver",683000,"Colorado"),
				new City("Salem",165000,"Oregon")
		};
		
		// array sorted alpha by city name using a lambda expression
		Arrays.sort(capitals,(c1,c2) -> c1.getName().compareTo(c2.getName()));
		
		System.out.println("State capital cities sorted by name");
		for(City c : capitals) {
			System.out.println(c);
		}
		
		ArrayList<City> caps = new ArrayList<>(Arrays.asList(capitals));
		
		// for binary search for a city, make a Comparator
        Comparator<City> cy = new Comparator<City>() { 
            public int compare(City c1, City c2) { 
                return c1.getName().compareTo(c2.getName()); 
            } 
        };
		// get name of city to find
        Scanner input = new Scanner(System.in);
		System.out.println("Enter city name for search");
		String city = input.nextLine();
		input.close();
		// make a new City with that city name
		City srchCity = new City(city,0,null);
		// perform the search
		int dex = Collections.binarySearch(caps,srchCity,cy);
		if(dex > -1) {
			System.out.println("Found " + city + " at index " + dex);
			System.out.println(caps.get(dex));
		}

		// add a few more capitals
		caps.add(new City("Tallahassee",192000,"Florida"));
		caps.add(new City("Honolulu",999000,"Hawaii"));
		
		Collections.sort(caps, new CityPopComparator());  // sort by pop
		
		System.out.println("\nState capital cities sorted by population");

		for(City c : caps) {
			System.out.println(c);
		}
	}
}
