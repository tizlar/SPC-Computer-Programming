package chap20x;

public class City {
	private String name;
	private int pop;
	private String state;

	public City(String name, int pop, String state) {
		super();
		this.name = name;
		this.pop = pop;
		this.state = state;
	}

	public int getPop() {
		return pop;
	}

	public void setPop(int pop) {
		this.pop = pop;
	}

	public String getName() {
		return name;
	}

	public String getState() {
		return state;
	}

	@Override
	public String toString() {
		return name + ", capital of " + state + ", population " + pop;
	}

}
