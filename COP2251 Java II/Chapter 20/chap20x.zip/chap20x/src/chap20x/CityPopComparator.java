package chap20x;

import java.io.Serializable;
import java.util.Comparator;

public class CityPopComparator implements Comparator<City>, Serializable {

	private static final long serialVersionUID = 1L;

	@Override
	public int compare(City arg0, City arg1) {	
		if(arg0.getPop() > arg1.getPop()) {
			return 1;
		}
		else if(arg0.getPop() < arg1.getPop()) {
			return -1;
		}
		else {
			return 0;
		}
	}
}
