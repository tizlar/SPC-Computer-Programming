package chap20x;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class Team {

	public static void main(String[] args) {
		
		Player p1 = new Player("Meadows",220,75);
		Player p2 = new Player("Choi",250,73);
		Player p6 = new Player("Heredia",195,70);
		Player p3 = new Player("Castillo",250,75);
		Player p4 = new Player("Lowe",185,70);
		Player p5 = new Player("Kiermaier",210,73);
		Player p7 = new Player("Kolarek",215,75);
		
		// make ArrayList from instances
		ArrayList<Player> rays = new ArrayList<>(Arrays.asList(p1,p2,p3,p4,p5,p6,p7));
		
		// sort by height with Comparator
		Collections.sort(rays,Comparator.comparing(Player::getHeight));
		
		System.out.println("Some Rays sorted by height");
		for(Player p : rays) {
			System.out.println(p);
		}
		
		// sort again by height, then weight
		Collections.sort(rays,
				Comparator.comparing(Player::getHeight).thenComparing(Player::getWeight));
		
		System.out.println("\nSome Rays sorted by height then weight");
		for(Player p : rays) {
			System.out.println(p);
		}	

		// reverse the sort order to decreasing height, then decreasing weight
		Collections.reverse(rays);
		
		System.out.println("\nReverse sorted");	
		// using foreach this time
		rays.forEach(e -> System.out.println(e));
	}
}
