package chap20n21;

public abstract class Asset {
	
	protected double appraised;
	
	public abstract double getAppraised();

}
