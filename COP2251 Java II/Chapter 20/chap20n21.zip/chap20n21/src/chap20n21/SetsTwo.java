package chap20n21;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetsTwo {

	public static void main(String[] args) {
		
		String[] names = {"Trump","May","Merkel","Trudeau","Kim"};
		
		Set<String> leaders = new LinkedHashSet<>();
		for(String s : names) {
			leaders.add(s);
		}
		
		System.out.println("Crude dump of leaders");
		System.out.println(leaders); // crude dump
		
		System.out.println("Leaders in alpha order");
		TreeSet<String> leaders2 = new TreeSet<>(leaders);
		for(String lead : leaders2) {
			System.out.print(lead + " ");
		}
	}
}
