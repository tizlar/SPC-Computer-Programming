package chap20n21;

public class House extends Asset {
	private String address;
	
	public House(String address, double appraised) {
		super();
		this.address = address;
		this.appraised = appraised;
	}

	public double getAppraised() {
		return appraised;
	}

	@Override
	public String toString() {
		return "House address at " + address + " has value " + appraised;
	}

}
