package chap20n21;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MapsOne {

	public static void main(String[] args) {
	
		Map<String,Integer> batting = new HashMap<>();
		batting.put("Longoria",350);
		batting.put("Morrison",325);
		batting.put("Sousa Jr",320);
		batting.put("Kiermaier",400);
		batting.put("Dickerson",375);
		
		System.out.println(batting); // crude dump, only for testing
		
		Set<String> batKeys = batting.keySet(); // get Set of just keys		
		System.out.println("\nRays Batting Stats - I wish\n");
		for(String s : batKeys) {
			// display key and get value for each key
			System.out.println(s + " is hitting " + batting.get(s));
		}
	
		// we make a TreeMap from the HashMap
		Map<String, Integer> batAlpha = new TreeMap<>(batting);
		Set<Map.Entry<String,Integer>> rays = batAlpha.entrySet();

		System.out.println("\nRays Batting Stats Alpha Order - I wish\n");
		for(Map.Entry<String, Integer> ray : rays) {
			System.out.println(ray.getKey() + " is hitting " + ray.getValue());
		}
		
	}
}
