package chap20n21;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;

public class ListLinked2 {

	public static void main(String[] args) {
		String[] giants = {"Hopper","Turing","Babbage","Atanasoff"};
		
		// NOTE type is Object 
		LinkedList<Object> gurus = new LinkedList<>();
		gurus.add("Gosling");
		gurus.add("Gates");
		gurus.add(new Integer(25));  // okay but...
		gurus.add(new Double(3.14159));
		gurus.addAll(Arrays.asList(giants));
		
		System.out.println("\nGurus, Giants and numbers foreach loop");		
		for(Object ob : gurus) {
			System.out.println(ob);
		}
		
		System.out.println("\nGurus and Giants and numbers iterated");				
		Iterator<Object> iter = gurus.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
	}
}
