package chap20n21;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class SetsOne {

	public static void main(String[] args) {

		Double[] dNums = { 1.1, 2.2, 3.3, 4.4, 5.5 };

		Set<Double> dubs = new HashSet<>(Arrays.asList(dNums));
		dubs.add(10.10);
		
		System.out.println("Set named dubs");
		for (double d : dubs) {
			System.out.print(d + " *** ");
		}
		System.out.println("\nNOTE: cannot control order of a hashset");
		
		Set<Double> dubs2 = addToSet(dubs);  // call method
	
		System.out.println();

		System.out.println("Set named dubs2");
		for (double d : dubs2) {
			System.out.print(d + " *** ");
		}
	}

	public static Set<Double> addToSet(Set<Double> mySet) {
		mySet.add(2.2);
		mySet.add(3.3);
		mySet.add(4.4);
		// none of above are added. Sets have no duplicates
		return mySet;
	}
}
