package chap20n21;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Vector;

public class AssetsValue {

	public static void main(String[] args) {
		
		Car car1 = new Car("Lamborghini","Centenario",1900000);
		House myHome = new House("666 Elm St",130000);
		Car car2 = new Car("Nissan","Leaf",8600);
		House condo = new House("100 Erehwon Ave",249000);
		Car car3 = new Car("Chevrolet","Bolt",36000);
		
		Vector<Asset> victor = new Vector<>();
		victor.add(car1);
		victor.add(car2);
		victor.add(condo);
		victor.add(myHome);
		victor.add(car3);
		
		Collections.sort(victor,new AssetComparator());
		
		System.out.println("My most valued asset: " + victor.get(3));
		
		System.out.println("\nAll of my assets, sorted ascending\n");
		for(Object ob : victor) {
			System.out.println(ob);
		}
		
		Integer[] ints = {10,20,30,40,50};
		Queue<Integer> nums = new LinkedList<>(Arrays.asList(ints));
		
		System.out.println("\nIntegers from a queue...FIFO");
		for(Integer n : nums) {
			System.out.print(n + " ");
		}
	}
}
