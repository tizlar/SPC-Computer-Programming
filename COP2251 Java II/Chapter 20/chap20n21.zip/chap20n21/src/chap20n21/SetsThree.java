package chap20n21;

import java.util.TreeSet;
import java.util.Vector;

public class SetsThree {

	public static void main(String[] args) {
		
		Car car1 = new Car("Lamborghini","Centenario",1900000);
		House myHome = new House("666 Elm St",130000);
		Car car2 = new Car("Nissan","Leaf",8600);
		House condo = new House("100 Erehwon Ave",249000);
		Car car3 = new Car("Chevrolet","Bolt",36000);
		
		Vector<Asset> victor = new Vector<>();
		victor.add(car1);
		victor.add(car2);
		victor.add(condo);
		victor.add(myHome);
		victor.add(car3);
		
		TreeSet<Asset> assets = new TreeSet<>(new AssetComparator());
		assets.addAll(victor);
		
		for(Asset a : assets) {
			System.out.println(a);
		}
	}
}
