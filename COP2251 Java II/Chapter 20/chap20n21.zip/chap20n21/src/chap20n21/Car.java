package chap20n21;

public class Car extends Asset {
	private String make;
	private String model;

	
	public Car(String make, String model, double worth) {
		super();
		this.make = make;
		this.model = model;
		this.appraised = worth;
	}

	public double getAppraised() {
		return appraised;
	}

	@Override
	public String toString() {
		return make + " " + model + ", worth is " + appraised;
	}
	
	
}
