package chap20n21;

import java.io.Serializable;
import java.util.Comparator;

public class AssetComparator implements Comparator<Asset>, Serializable {
	private static final long serialVersionUID = 1L;

	@Override
	public int compare(Asset arg0, Asset arg1) {
		double value1 = arg0.getAppraised();
		double value2 = arg1.getAppraised();
		
		if (value1 > value2) {
			return 1;
		} else if (value1 < value2) {
			return -1;
		} else {
			return 0;
		}
	}
}
