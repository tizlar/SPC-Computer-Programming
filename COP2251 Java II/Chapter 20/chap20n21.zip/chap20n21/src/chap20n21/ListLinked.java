package chap20n21;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class ListLinked {

	public static void main(String[] args) {
		String[] giants = {"Hopper","Turing","Babbage","Atanasoff"};
		
		LinkedList<String> gurus = new LinkedList<>();
		gurus.add("Gosling");
		gurus.add("Gates");
		gurus.addAll(Arrays.asList(giants));
		
		System.out.println("Gurus and Giants");
		ListIterator<String> lister = gurus.listIterator();
		while(lister.hasNext()) {
			System.out.println(lister.next());
		}

		System.out.println("\nGurus and Giants backwards");
		while(lister.hasPrevious()) {
			System.out.println(lister.previous());
		}
		
		System.out.println("\nGurus and Giants iterated");				
		Iterator<String> iter = gurus.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
	}
}
