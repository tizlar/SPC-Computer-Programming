package chap44example;

public class Employee {
	
	private String name;
	private double salary;
	private String position;
	
	public Employee(String name, double salary, String position) {
		super();
		this.name = name;
		this.salary = salary;
		this.position = position;
	}
	
	public double deduct(double rate) {
		return this.salary * rate / 100;
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	public String getPosition() {
		return position;
	}

	@Override
	public String toString() {
		return name + ", " + position + ", " + String.format("salary $%,.0f", salary);
	}
}
