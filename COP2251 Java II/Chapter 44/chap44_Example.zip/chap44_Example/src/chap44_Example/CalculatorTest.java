package chap44_Example;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.*;

class CalculatorTest {

    @BeforeAll
    public static void setUpClass() {
        // code executed before all test methods
    }
     
    @BeforeEach
    public void setUp() {
        // code executed before each test method
    }
     
    @Test
    public void testAdd() {
        Calculator calculator = new Calculator();
        int a = 1234;
        int b = 5678;
        int actual = calculator.add(a, b);
     
        int expected = 6912;
     
        assertEquals(expected, actual);
    }
     
    @Test
    public void testSubtract() {
        Calculator calculator = new Calculator();
        int a = 1234;
        int b = 5678;
        int actual = calculator.subtract(b, a);
     
        int expected = 4444;
     
        assertEquals(expected, actual);
    }
     
    @AfterEach
    public void tearDown() {
        // code executed after each test method
    }
     
    @AfterAll
    public static void tearDownClass() {
        // code executed after all test methods
    }

}
