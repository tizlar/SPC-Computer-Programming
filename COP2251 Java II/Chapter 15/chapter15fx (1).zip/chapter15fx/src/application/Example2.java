package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Example2 extends Application {

	@Override
	public void start(Stage primaryStage) {
		GridPane pane = new GridPane();
		pane.setPadding(new Insets(11, 12, 13, 14));
		pane.setHgap(5);
		pane.setVgap(5);
		
		ImageView img1 = new ImageView(new Image("us.gif"));
		pane.add(img1,0,0);
		
		ImageView img2 = new ImageView(new Image("flag5.gif"));
		ImageView img3 = new ImageView(new Image("ca.gif"));
		pane.add(img2,1,1);
		pane.add(img3, 1, 0);

		Scene scene = new Scene(pane, 500, 500);
		primaryStage.setTitle("ShowFlowPane"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}

	public static void main(String[] args) {
		launch(args);
	}
}
