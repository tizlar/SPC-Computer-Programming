package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class Example5 extends Application {

	@Override
	public void start(Stage primaryStage) throws InterruptedException {
		Pane pane = new Pane();


		for (int i = 10; i <= 200; i += 5) {
			Circle c = new Circle(i * 2, i * 2, i);
			c.setStroke(Color.color(Math.random(), Math.random(), Math.random()));
			c.setStrokeWidth(5);
			c.setFill(null);
			pane.getChildren().add(c);		
		}

		Scene scene = new Scene(pane, 700, 700);
		primaryStage.setTitle("Circles"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}

	public static void main(String[] args) {
		launch(args);
	}
}
