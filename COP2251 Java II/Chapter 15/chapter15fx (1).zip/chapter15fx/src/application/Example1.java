package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class Example1 extends Application {

	@Override
	public void start(Stage primaryStage) {
		FlowPane pane = new FlowPane();
		pane.setPadding(new Insets(11, 12, 13, 14));
		pane.setHgap(5);
		pane.setVgap(5);
		
		Image im1 = new Image("us.gif");
		Image im2 = new Image("flag5.gif");
		Image im3= new Image("ca.gif");
		
		ImageView img1 = new ImageView(im1);
		pane.getChildren().add(img1);
		
		ImageView img2 = new ImageView(im2);
		ImageView img3 = new ImageView(im3);
		pane.getChildren().addAll(img2,img3);

		Scene scene = new Scene(pane, 500, 500);
		primaryStage.setTitle("ShowFlowPane"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}

	public static void main(String[] args) {
		launch(args);
	}
}
