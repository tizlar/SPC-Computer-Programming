package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class Example6 extends Application {

	@Override
	public void start(Stage primaryStage) {
		FlowPane pane = new FlowPane();
		pane.setPadding(new Insets(11, 12, 13, 14));
		pane.setHgap(5);
		pane.setVgap(5);
		
		for (int i = 1; i <= 52; i++) {
			Integer cd = i;
			String s = cd.toString();
			ImageView crd = new ImageView(new Image(s + ".png"));
			pane.getChildren().add(crd);			
		}
		
		pane.setStyle("-fx-background-color:green");
		
		Scene scene = new Scene(pane, 1050, 440);
		primaryStage.setTitle("Poker Hands"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}

	public static void main(String[] args) {
		launch(args);
	}
}
