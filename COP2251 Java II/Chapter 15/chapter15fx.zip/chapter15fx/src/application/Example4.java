package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Example4 extends Application {

	@Override
	public void start(Stage primaryStage) {
		VBox player = new VBox(10);
		player.setPadding(new Insets(10, 10, 10, 10));

		Text txtP = new Text(1,1,"Player");
		txtP.setFill(Color.WHITE);
		txtP.setFont(Font.font("Verdana", FontWeight.BOLD, 10));
		player.getChildren().add(txtP);
		for (int i = 1; i <= 5; i++) {
			Integer rnd = (int)(Math.random() * 52) + 1;
			String s = rnd.toString();
			ImageView crd = new ImageView(new Image(s + ".png"));
			player.getChildren().add(crd);
		}
		
		VBox computer = new VBox(10);
		computer.setPadding(new Insets(10, 10, 10, 10));
		
		Text txtC = new Text(1,1,"Computer");
		txtC.setFill(Color.YELLOW);
		txtC.setFont(Font.font("Verdana", FontWeight.BOLD, 10));
		computer.getChildren().add(txtC);
		
		for (int i = 1; i <= 5; i++) {
			Integer rnd = (int)(Math.random() * 52) + 1;
			String s = rnd.toString();
			ImageView crd = new ImageView(new Image(s + ".png"));
			computer.getChildren().add(crd);			
		}
		player.setStyle("-fx-background-color:green");
		computer.setStyle("-fx-background-color:green");
				
		FlowPane hands = new FlowPane();
		hands.setPadding(new Insets(11, 12, 13, 14));
		hands.setVgap(10);
		hands.getChildren().addAll(player,computer);
		
		Scene scene = new Scene(hands, 250, 600);
		primaryStage.setTitle("Poker Hands"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}

	public static void main(String[] args) {
		launch(args);
	}
}
