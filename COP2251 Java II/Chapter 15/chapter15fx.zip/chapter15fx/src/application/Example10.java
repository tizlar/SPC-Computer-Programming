package application;

import java.text.NumberFormat;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Example10 extends Application {
	// controls for form
	private GridPane form;
	private Label lbQuantity = new Label("Quantity");
	private Label lbPrice = new Label("Unit Price");
	private Label lbSubtot = new Label("Subtotal");
	private Label lbTax = new Label("Sales Tax");
	private Label lbTotal = new Label("Total");
	private TextField tfQuantity = new TextField();
	private TextField tfPrice = new TextField();
	private Label lbSubtotAmt = new Label();
	private Label lbTaxAmt = new Label();
	private Label lbTotalAmt = new Label();
	private Button btSubmit = new Button("Submit");

	@Override
	public void start(Stage primaryStage) {
		// create the form
		form = new GridPane();
		form.setPadding(new Insets(10, 10, 10, 10));
		form.setHgap(5);
		form.setVgap(5);
		// add controls
		form.add(lbQuantity, 0, 0);
		form.add(lbPrice, 0, 1);
		form.add(lbSubtot, 0, 2);
		form.add(lbTax, 0, 3);
		form.add(lbTotal, 0, 4);
		form.add(tfQuantity, 1, 0);
		form.add(tfPrice,1,1);
		form.add(lbSubtotAmt, 1, 2);
		form.add(lbTaxAmt, 1, 3);
		form.add(lbTotalAmt, 1, 4);
		form.add(btSubmit, 1, 5);
		form.setStyle("-fx-background-color:yellow");
		btSubmit.setStyle("-fx-background-color:lightgreen");
		
		// register and code the lambda button handler
		btSubmit.setOnAction(e -> {
			// read the form inputs
			int qty = Integer.parseInt(tfQuantity.getText());
			double price = Double.parseDouble(tfPrice.getText());
			// do the math
			double sub = qty * price;
			double tax = sub * 0.07;
			double total = sub + tax;
			// complete the form, using class NumberFormat for currency
			NumberFormat fmt = NumberFormat.getCurrencyInstance();
			lbSubtotAmt.setText(fmt.format(sub));
			lbTaxAmt.setText(fmt.format(tax));
			lbTotalAmt.setText(fmt.format(total));	
		});
		
		Scene scene = new Scene(form, 240, 180);
		primaryStage.setTitle("Cashier"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}

	public static void main(String[] args) {
		launch(args);
	}
}
