package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Example9 extends Application {
	// declaring attributes here makes them accessible
	private GridPane grid;
	private Button hand;

	@Override
	public void start(Stage primaryStage) {
		// now we create the GridPane object
		grid = new GridPane();
		grid.setPadding(new Insets(10, 10, 10, 10));
		grid.setHgap(5);
		grid.setVgap(5);

		hand = new Button("New Hand");
		// using a lambda expression as the event handler
		// compiler knows that a Button handler uses ActionEvent
		hand.setOnAction(e -> {
			for (int i = 1; i <= 5; i++) {
				Integer rnd = (int) (Math.random() * 52) + 1;
				String s = rnd.toString();
				ImageView crd = new ImageView(new Image(s + ".png"));
				grid.add(crd, i, 0);
			}
		});
		
		// add button to the first cell in the grid
		grid.add(hand, 0, 0);

		Scene scene = new Scene(grid, 500, 500);
		primaryStage.setTitle("Poker Hands"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}

	public static void main(String[] args) {
		launch(args);
	}
}
