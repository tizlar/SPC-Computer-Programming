package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Example3 extends Application {

	@Override
	public void start(Stage primaryStage) {
		GridPane player = new GridPane();
		player.setPadding(new Insets(10, 10, 10, 10));
		player.setHgap(5);
		player.setVgap(5);
		
		GridPane computer = new GridPane();
		computer.setPadding(new Insets(10, 10, 10, 10));
		computer.setHgap(5);
		computer.setVgap(5);

		player.add(new Text(1,1,"Player"),0,0);
		for (int i = 1; i <= 5; i++) {
			Integer rnd = (int)(Math.random() * 52) + 1;
			String s = rnd.toString();
			Image card = new Image(s + ".png");
			ImageView crd = new ImageView(card);
			player.add(crd, i, 0);
		}
		computer.add(new Text(1,1,"Computer"), 0, 0);
		for (int i = 1; i <= 5; i++) {
			Integer rnd = (int)(Math.random() * 52) + 1;
			String s = rnd.toString();
			ImageView crd = new ImageView(new Image(s + ".png"));
			computer.add(crd, i, 0);			
		}
		
		FlowPane hands = new FlowPane();
		hands.setVgap(10);
		hands.getChildren().addAll(player,computer);
		
		Scene scene = new Scene(hands, 500, 500);
		primaryStage.setTitle("Poker Hands"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}

	public static void main(String[] args) {
		launch(args);
	}
}
